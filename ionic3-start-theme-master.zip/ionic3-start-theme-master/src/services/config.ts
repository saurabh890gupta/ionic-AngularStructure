export class config {
	//SERVER_URL: 'http://192.168.1.129/android/v1/Api.php',
	public URL:string= 'http://192.168.1.129/android/v1/Api.php'
}
